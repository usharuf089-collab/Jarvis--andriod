# ProGuard rules for Jarvis Android Assistant
-keep class com.jarvis.assistant.** { *; }
