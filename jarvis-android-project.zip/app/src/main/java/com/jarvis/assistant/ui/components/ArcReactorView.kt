package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisAmber
import com.jarvis.assistant.ui.theme.JarvisCyan
import com.jarvis.assistant.ui.theme.JarvisCyanBright
import com.jarvis.assistant.ui.theme.JarvisCyanGlow
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorView(
    isListening: Boolean,
    audioRms: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorRotation")

    // Outer ring clockwise rotation
    val rotationClockwise by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 4000 else 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Clockwise"
    )

    // Inner ring counter-clockwise rotation
    val rotationCounter by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 6000 else 24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "CounterClockwise"
    )

    val normalizedRms = ((audioRms + 2f) / 12f).coerceIn(0f, 1f)
    val pulseScale = if (isListening) 1f + normalizedRms * 0.25f else 1f

    Box(
        modifier = modifier
            .size(240.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(240.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val baseRadius = (size.minDimension / 2) * 0.9f

            // 1. Dynamic Audio Pulse Expansion Ring
            if (isListening) {
                drawCircle(
                    color = JarvisCyanBright.copy(alpha = 0.25f),
                    radius = baseRadius * pulseScale,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
            }

            // 2. Outer Dashed Tech Ring
            rotate(rotationClockwise, pivot = center) {
                drawCircle(
                    color = JarvisCyanGlow.copy(alpha = 0.5f),
                    radius = baseRadius * 0.95f,
                    center = center,
                    style = Stroke(
                        width = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                    )
                )

                // 8 Arc segments
                for (i in 0 until 8) {
                    val angle = Math.toRadians((i * 45).toDouble())
                    val startR = baseRadius * 0.78f
                    val endR = baseRadius * 0.92f
                    val start = Offset(
                        center.x + (cos(angle) * startR).toFloat(),
                        center.y + (sin(angle) * startR).toFloat()
                    )
                    val end = Offset(
                        center.x + (cos(angle) * endR).toFloat(),
                        center.y + (sin(angle) * endR).toFloat()
                    )
                    drawLine(
                        color = JarvisCyanBright,
                        start = start,
                        end = end,
                        strokeWidth = 3.dp.toPx()
                    )
                }
            }

            // 3. Middle Counter-Rotating Gear Ring
            rotate(rotationCounter, pivot = center) {
                drawCircle(
                    color = JarvisCyan.copy(alpha = 0.7f),
                    radius = baseRadius * 0.72f,
                    center = center,
                    style = Stroke(
                        width = 4.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 10f), 0f)
                    )
                )
            }

            // 4. Inner Glowing Ring
            drawCircle(
                color = JarvisCyanGlow.copy(alpha = 0.3f),
                radius = baseRadius * 0.5f,
                center = center
            )
            drawCircle(
                color = JarvisCyanBright,
                radius = baseRadius * 0.48f,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // 5. Central Reactor Core (High Energy Light)
            val coreColor = if (isListening) JarvisCyanBright else JarvisCyan
            drawCircle(
                color = coreColor,
                radius = baseRadius * 0.26f * pulseScale,
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = baseRadius * 0.12f,
                center = center
            )
        }
    }
}
