package com.jarvis.assistant.data

enum class CommandIntent {
    CALL,
    SMS,
    WHATSAPP,
    OPEN_APP,
    TORCH,
    BATTERY,
    VIBRATE,
    SETTINGS,
    REMINDER,
    SCHEDULE,
    TIME,
    STATUS,
    UNKNOWN
}

data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val relation: String
)

data class AppShortcut(
    val id: String,
    val name: String,
    val packageName: String,
    val actionUri: String? = null
)

data class Reminder(
    val id: String,
    val title: String,
    val time: String,
    val isCompleted: Boolean = false
)

data class ScheduleItem(
    val id: String,
    val time: String,
    val title: String,
    val isCompleted: Boolean = false
)

data class CommandResult(
    val rawText: String,
    val intent: CommandIntent,
    val feedback: String,
    val target: String? = null,
    val message: String? = null
)
