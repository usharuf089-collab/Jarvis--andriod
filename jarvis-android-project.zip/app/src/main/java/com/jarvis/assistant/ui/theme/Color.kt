package com.jarvis.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisBackground = Color(0xFF030712)
val JarvisSurface = Color(0xFF0F172A)
val JarvisCyan = Color(0xFF06B6D4)
val JarvisCyanBright = Color(0xFF38BDF8)
val JarvisCyanGlow = Color(0xFF0284C7)
val JarvisAmber = Color(0xFFF59E0B)
val JarvisTextPrimary = Color(0xFFF8FAFC)
val JarvisTextSecondary = Color(0xFF94A3B8)
val JarvisBorder = Color(0xFF164E63)
