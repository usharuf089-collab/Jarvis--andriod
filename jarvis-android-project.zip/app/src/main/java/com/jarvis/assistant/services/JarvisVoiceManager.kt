package com.jarvis.assistant.services

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.jarvis.assistant.data.CommandIntent
import com.jarvis.assistant.data.CommandResult
import com.jarvis.assistant.data.Contact
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisVoiceManager(
    private val context: Context,
    private val onResult: (String, CommandResult) -> Unit,
    private val onRmsChanged: (Float) -> Unit,
    private val onListeningStateChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isTtsReady: Boolean = false

    init {
        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        onListeningStateChanged(true)
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        onRmsChanged(rmsdB)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        onListeningStateChanged(false)
                    }

                    override fun onError(error: Int) {
                        onListeningStateChanged(false)
                    }

                    override fun onResults(results: Bundle?) {
                        onListeningStateChanged(false)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull() ?: return
                        val parsed = parseOfflineCommand(spokenText, emptyList())
                        onResult(spokenText, parsed)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        onListeningStateChanged(false)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.ENGLISH
            tts?.setPitch(0.92f)
            tts?.setSpeechRate(1.05f)
            isTtsReady = true
        }
    }

    fun speak(text: String) {
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_UTTERANCE")
        }
    }

    fun destroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }

    // High speed local Kotlin Offline Intent Parser
    fun parseOfflineCommand(text: String, contacts: List<Contact>): CommandResult {
        val lower = text.trim().lowercase(Locale.ROOT)

        // 1. Call Intent
        if (lower.startsWith("call ") || lower.startsWith("dial ") || lower.contains("ko call")) {
            val target = lower.replace(Regex("^(call|dial)\\s+"), "").replace(Regex("(\\s+ko call.*)"), "").trim()
            val matchedContact = contacts.find { it.name.lowercase(Locale.ROOT).contains(target) }
            val phone = matchedContact?.phone ?: target
            return CommandResult(
                rawText = text,
                intent = CommandIntent.CALL,
                feedback = "Initiating call to ${matchedContact?.name ?: target}",
                target = phone
            )
        }

        // 2. WhatsApp Intent
        if (lower.contains("whatsapp")) {
            return CommandResult(
                rawText = text,
                intent = CommandIntent.WHATSAPP,
                feedback = "Opening WhatsApp interface, Sir.",
                message = text.replace(Regex(".*whatsapp\\s*"), "")
            )
        }

        // 3. SMS Intent
        if (lower.startsWith("sms ") || lower.startsWith("message ") || lower.contains("message")) {
            return CommandResult(
                rawText = text,
                intent = CommandIntent.SMS,
                feedback = "Preparing mobile message directive.",
                message = text
            )
        }

        // 4. Torch / Flashlight
        if (lower.contains("torch") || lower.contains("flashlight") || lower.contains("light")) {
            val isOff = lower.contains("off") || lower.contains("band")
            return CommandResult(
                rawText = text,
                intent = CommandIntent.TORCH,
                feedback = if (isOff) "Torch deactivated, Sir." else "Torch activated, Sir.",
                target = if (isOff) "false" else "true"
            )
        }

        // 5. Battery
        if (lower.contains("battery") || lower.contains("charging")) {
            return CommandResult(
                rawText = text,
                intent = CommandIntent.BATTERY,
                feedback = "Retrieving battery telemetry parameters."
            )
        }

        // 6. Settings
        if (lower.contains("setting") || lower.contains("wifi") || lower.contains("bluetooth")) {
            val sub = when {
                lower.contains("wifi") -> "wifi"
                lower.contains("bluetooth") -> "bluetooth"
                lower.contains("sound") -> "sound"
                lower.contains("display") -> "display"
                else -> "general"
            }
            return CommandResult(
                rawText = text,
                intent = CommandIntent.SETTINGS,
                feedback = "Accessing Android $sub configuration.",
                target = sub
            )
        }

        // 7. Time
        if (lower.contains("time") || lower.contains("samay")) {
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            return CommandResult(
                rawText = text,
                intent = CommandIntent.TIME,
                feedback = "The current time is $timeStr, Sir."
            )
        }

        // 8. Reminders
        if (lower.contains("remind") || lower.contains("reminder") || lower.contains("yaad")) {
            val title = lower.replace(Regex("^(remind me to|reminder for)\\s*"), "").trim()
            return CommandResult(
                rawText = text,
                intent = CommandIntent.REMINDER,
                feedback = "Reminder scheduled: \"$title\"",
                message = title
            )
        }

        // 9. Status
        if (lower.contains("status") || lower.contains("hello") || lower.contains("namaste")) {
            return CommandResult(
                rawText = text,
                intent = CommandIntent.STATUS,
                feedback = "All Android native subsystems nominal and awaiting directives, Sir."
            )
        }

        // App Launch intent default
        return CommandResult(
            rawText = text,
            intent = CommandIntent.OPEN_APP,
            feedback = "Processing directive: $text",
            target = lower
        )
    }
}
