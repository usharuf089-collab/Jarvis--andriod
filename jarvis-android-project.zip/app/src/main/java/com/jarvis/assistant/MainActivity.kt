package com.jarvis.assistant

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.data.CommandIntent
import com.jarvis.assistant.data.Contact
import com.jarvis.assistant.data.Reminder
import com.jarvis.assistant.services.JarvisVoiceManager
import com.jarvis.assistant.services.PhoneController
import com.jarvis.assistant.ui.components.ArcReactorView
import com.jarvis.assistant.ui.theme.*

class MainActivity : ComponentActivity() {

    private lateinit var phoneController: PhoneController
    private var voiceManager: JarvisVoiceManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        phoneController = PhoneController(this)

        // Keep screen on during assistant usage
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            JarvisTheme {
                MainScreen(phoneController = phoneController)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager?.destroy()
    }
}

@Composable
fun MainScreen(phoneController: PhoneController) {
    var isListening by remember { mutableStateOf(false) }
    var audioRms by remember { mutableStateOf(0f) }
    var jarvisFeedback by remember { mutableStateOf("Jarvis Native Android OS online. Awaiting your directive, Sir.") }
    var lastSpokenText by remember { mutableStateOf("") }
    var isTorchActive by remember { mutableStateOf(false) }

    val defaultContacts = remember {
        listOf(
            Contact("1", "Papa", "9876543210", "Family"),
            Contact("2", "Mummy", "9876543211", "Family"),
            Contact("3", "Emergency", "112", "Emergency")
        )
    }

    var reminders by remember {
        mutableStateOf(
            listOf(
                Reminder("1", "Hydration check (Drink Water)", "11:00 AM"),
                Reminder("2", "Review Android Project", "04:30 PM"),
                Reminder("3", "Take Vitamin / Medicine", "09:30 PM")
            )
        )
    }

    val context = androidx.compose.ui.platform.LocalContext.current

    val voiceManager = remember {
        JarvisVoiceManager(
            context = context,
            onResult = { raw, result ->
                lastSpokenText = raw
                jarvisFeedback = result.feedback
                phoneController.vibrate(100)

                when (result.intent) {
                    CommandIntent.CALL -> {
                        val number = result.target ?: "9876543210"
                        phoneController.dialCall(number)
                    }
                    CommandIntent.WHATSAPP -> {
                        phoneController.openWhatsApp(null, result.message ?: "Hello from Jarvis")
                    }
                    CommandIntent.SMS -> {
                        phoneController.sendSms(result.target ?: "9876543210", result.message ?: "")
                    }
                    CommandIntent.TORCH -> {
                        val turnOn = result.target != "false"
                        isTorchActive = phoneController.toggleTorch(turnOn)
                    }
                    CommandIntent.BATTERY -> {
                        val level = phoneController.getBatteryLevel()
                        jarvisFeedback = "Battery level is currently at $level percent, Sir."
                    }
                    CommandIntent.SETTINGS -> {
                        phoneController.openSettings(result.target ?: "general")
                    }
                    CommandIntent.REMINDER -> {
                        val newTitle = result.message ?: "New Task"
                        reminders = listOf(Reminder(System.currentTimeMillis().toString(), newTitle, "Today")) + reminders
                    }
                    CommandIntent.OPEN_APP -> {
                        val target = result.target ?: ""
                        if (target.contains("youtube")) phoneController.launchApp("com.google.android.youtube")
                        else if (target.contains("camera")) phoneController.launchApp("com.google.android.GoogleCamera")
                        else if (target.contains("chrome")) phoneController.launchApp("com.android.chrome")
                        else if (target.contains("spotify")) phoneController.launchApp("com.spotify.music")
                    }
                    else -> {}
                }
            },
            onRmsChanged = { rms -> audioRms = rms },
            onListeningStateChanged = { listening -> isListening = listening }
        )
    }

    // Permissions launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val recordAllowed = perms[Manifest.permission.RECORD_AUDIO] == true
        if (recordAllowed) {
            voiceManager.startListening()
        }
    }

    val handleToggleListening = {
        if (isListening) {
            voiceManager.stopListening()
        } else {
            permissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.CAMERA
                )
            )
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = JarvisBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Telemetry Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(JarvisCyanBright)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "J.A.R.V.I.S. NATIVE OS",
                        color = JarvisCyanBright,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "BATT: ${phoneController.getBatteryLevel()}%",
                    color = JarvisTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Central Animated Arc Reactor
            ArcReactorView(
                isListening = isListening,
                audioRms = audioRms,
                onClick = { handleToggleListening() },
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Text(
                text = if (isListening) "LISTENING FOR DIRECTIVE..." else "TAP REACTOR TO COMMAND",
                color = if (isListening) JarvisAmber else JarvisCyanBright,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Live Feedback Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, JarvisBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = JarvisSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (lastSpokenText.isNotEmpty()) {
                        Text(
                            text = "COMMAND: \"$lastSpokenText\"",
                            color = JarvisTextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Text(
                        text = jarvisFeedback,
                        color = JarvisCyanBright,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Quick Control Tiles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        phoneController.dialCall(defaultContacts.first().phone)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call", fontSize = 11.sp, color = JarvisTextPrimary, fontFamily = FontFamily.Monospace)
                }

                Button(
                    onClick = {
                        isTorchActive = phoneController.toggleTorch()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isTorchActive) JarvisAmber.copy(alpha = 0.2f) else JarvisSurface
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Icon(Icons.Default.FlashlightOn, contentDescription = null, tint = if (isTorchActive) JarvisAmber else JarvisCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isTorchActive) "Torch ON" else "Torch", fontSize = 11.sp, color = JarvisTextPrimary, fontFamily = FontFamily.Monospace)
                }

                Button(
                    onClick = {
                        phoneController.openSettings("wifi")
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Icon(Icons.Default.Wifi, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Wi-Fi", fontSize = 11.sp, color = JarvisTextPrimary, fontFamily = FontFamily.Monospace)
                }
            }

            // Reminders / Schedule Agenda Section
            Text(
                text = "OPERATIONAL AGENDA",
                color = JarvisTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(reminders) { rem ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, JarvisBorder.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = JarvisSurface.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = rem.title,
                                    color = JarvisTextPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = rem.time,
                                    color = JarvisCyan,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = JarvisCyanGlow,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
